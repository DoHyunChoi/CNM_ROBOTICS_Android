package user.example.com.cnm_test01;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView TextView1;
    TextView TextView2;
    TextView TextViewTM;
    TextView TextViewCO2;

    private BackPressCloseHandler backPressCloseHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView1 = (TextView)findViewById(R.id.textView1);
        TextView2 = (TextView)findViewById(R.id.textView2);
        TextViewTM = (TextView)findViewById(R.id.textViewTM);
        TextViewCO2 = (TextView)findViewById(R.id.textviewCO2);
        findViewById(R.id.button_TM).setOnClickListener(button_TM);
        findViewById(R.id.button_CO2).setOnClickListener(button_CO2);
        findViewById(R.id.button_graph).setOnClickListener(button_graph);
        findViewById(R.id.result).setOnClickListener(result);

        backPressCloseHandler = new BackPressCloseHandler(this);

    }

    Button.OnClickListener button_TM = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {

            TextViewTM.setText("온습도 센서값");

        }
    };
    Button.OnClickListener button_CO2 = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {

            TextViewCO2.setText("CO2 센서값");

        }
    };
    Button.OnClickListener button_graph = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {

            Toast toast = Toast.makeText(MainActivity.this, "그래프를 보여드립니다.", Toast.LENGTH_LONG);
            toast.show();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://thingspeak.com/channels/209199"));
            startActivity(intent);
            finish();
        }
    };
    Button.OnClickListener result = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {

                Toast toast = Toast.makeText(MainActivity.this, "결과창입니다.", Toast.LENGTH_LONG);
                toast.show();
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://192.168.0.182"));
                startActivity(intent);
            }
        };

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        backPressCloseHandler.onBackPressed();

    }


}
