package user.example.com.mqttapptest;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MainActivity extends AppCompatActivity {

    static String MQTTHOST = "tcp://broker.mqtt-dashboard.com:1883";
    String topicStr = "CNM/ROTICS/TEST/Ajou";
    String humidStr = "Humidity_DOHYUN(%)";
    String temperStr = "Temperature_DOHYUN(C)";
    String co2Str = "Co2_DOHYUN(ppm)";


    MqttAndroidClient client;
    TextView subText;
    TextView co2Text,humidText,tempText;
    TextView topictextview;
    MqttConnectOptions options = new MqttConnectOptions();
    Vibrator vibrator;
    Ringtone ringtone;
    IMqttToken token;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        subText = (TextView)findViewById(R.id.subText);
        co2Text = (TextView)findViewById(R.id.co2Text);
        humidText = (TextView)findViewById(R.id.humidText);
        tempText = (TextView)findViewById(R.id.tempText);
        topictextview = (TextView)findViewById(R.id.topictextview);

        vibrator = (Vibrator)getSystemService(VIBRATOR_SERVICE);
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        ringtone = RingtoneManager.getRingtone(getApplicationContext(),uri);

        String clientId = MqttClient.generateClientId();
        client = new MqttAndroidClient(this.getApplicationContext(), MQTTHOST, clientId);

        options = new MqttConnectOptions();

      //  options.setUserName("USERNAME");
      //  options.setPassword("PASSWORD".toCharArray());


        try {
             token = client.connect(options);
             token = client.connect();
             token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Toast.makeText(MainActivity.this, "connected!!",Toast.LENGTH_LONG).show();
                    setSubscription();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Toast.makeText(MainActivity.this, "connection failed",Toast.LENGTH_LONG).show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                //subText.setText(new String(message.getPayload()));
                //topictextview.setText(topic);
                subText.setText("Sensor checking");
                topictextview.setText("IoT 스마트식물공장");

                if(topic.equals(co2Str))
                    co2Text.setText(new String(message.getPayload()));
                else if(topic.equals(temperStr))
                    tempText.setText(new String(message.getPayload()));
                else
                    humidText.setText(new String(message.getPayload()));

                vibrator.vibrate(500);
                ringtone.play();
            }


            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });
    }



    public void pub(View v) {
            String topic = topicStr;
            String message = "Beginning ICT from DoHyunChoi";

            try {
                client.publish(topic, message.getBytes(), 0, false);


            } catch (MqttException e) {
                e.printStackTrace();
            }

    }
    private void setSubscription(){
        try{
            client.subscribe(topicStr,0);
            client.subscribe(humidStr,0);
            client.subscribe(temperStr,0);
            client.subscribe(co2Str,0);

        }catch (MqttException e) {
            e.printStackTrace();
        }
    }
    public void conn(View v) {
        try {
            token = client.connect(options);
            token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Toast.makeText(MainActivity.this, "connected!!",Toast.LENGTH_LONG).show();
                    setSubscription();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Toast.makeText(MainActivity.this, "connection failed",Toast.LENGTH_LONG).show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    public void disconn(View v){
        try {
            token = client.disconnect();
            token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Toast.makeText(MainActivity.this, "disconnected",Toast.LENGTH_LONG).show();

                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Toast.makeText(MainActivity.this, "could not disconnect..",Toast.LENGTH_LONG).show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
